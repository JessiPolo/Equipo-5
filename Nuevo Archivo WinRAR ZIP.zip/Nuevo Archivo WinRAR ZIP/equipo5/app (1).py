from flask import Flask, render_template, request

from app1 import registro_medico

app = Flask(__name__)

lista_pacientes = ["Marcos", "Maria"]
lista_medicos = ["Pedro", "Carmen"]
lista_admin = ["Stiven"]
lista_comentarios = {
"1": "Marcos: Muy buena atencion por parte de los medicos",
"2": "Maria: Gracias por la pronta atencion",
"3": "Dr. Pedro: Por este espacio no se pueden pedir citas, para ello vaya al apartado de citas"

}
listado_citas={"medico general", "pedro", "6am - 12pm"}
lista_citas = {
"medicogeneral":"Pedro: 6am - 12pm", 
"psicologia":"Carmen: 8am - 3 pm", 
"neurologia": "Carlos: 12pm - 8 pm", 
"cuidado del embarazo":"Laura: 12pm - 6 pm", 
"pediatria": "Karol: 7am - 3 pm", 
"cardiologia":"Mario: 6 am - 2 pm"}
@app.route("/", methods= ["GET"])
def inicio():
    return "pagina de inicio"
#ESTA MADRE NO ME SALE, MIIRA SI TE SALE A TI
@app.route("/listadecitas2/<namee>", methods=["GET", "POST"])
def lista2decitas(namee):
    if request.method=="POST":
        car=request.form.get("cardiologia")
        ped=request.form.get("pediatria")
        neu=request.form.get("neurologia")
        cui=request.form.get("cuidado")
        med=request.form.get("medicogeneral")
        psi=request.form.get("psicologia")
        name2=request.form.get("nombre")
        horario1=request.form.get("opcion1")
        horario2=request.form.get("opcion2")
        horario3=request.form.get("opcion3")
        horario4=request.form.get("opcion4")
        horario5=request.form.get("opcion5")
        horario6=request.form.get("opcion6")
        añadir = listado_citas.append(car)
        añadir7=listado_citas.append(name2)
        añadir8=listado_citas.append(horario1)
        #objeto = {'cardiologia': car, 'pediatria':ped, 'neurologia':neu, 'cuidado':cui, 'medicogeneral':med, 'psicologia':psi, 'nombre':name2, 'opcion1':horario1, 'opcion2':horario2, 'opcion3':horario3, 'opcion4':horario4, 'opcion5':horario5, 'opcion6':horario6}
        #lista_citas.append(objeto)
    return render_template("listadecitas.html")
###########
@app.route("/registrop/<registro_paciente>", methods= ["GET", "POST"])
def registropaciente(registro_paciente):
    
    if registro_paciente:
        lista_pacientes.append(registro_paciente)
        return f"paciente registrado exitosamente, bienvenid@ {registro_paciente}\n{lista_pacientes}"
@app.route("/registra/<registrp>", methods=["GET", "POST"])
def registrodelmedico(registrp):
    if request.method=="POST":
        name = request.form.get("nombre")
        lastname = request.form.get("apellido")
        age = request.form.get("edad")
        id3 = request.form.get("id")
        idee= request.form.get("cedula")
        ideee= request.form.get("tarjeta")
        phone=request.form.get("telefono")
        email=request.form.get("correo")
        passs=request.form.get("contraseña")
        añadir = lista_pacientes.append(name)
        añadir4=lista_pacientes.append(lastname)
        añadir5=lista_pacientes.append(age)
        añadir6=lista_pacientes.append(ide3)
        añadir8=lista_pacientes.append(phone)
        añadir9=lista_pacientes.append(email)
        añadir10=ñista_paciente.append(passs)
        if idee:
            añadir2=lista_pacientes.append(idee)
        elif ideee:
            añadir3=lista_pacientes.append(ideee)
        print(añadir)
    return render_template('formularioRegistro.html')



@app.route("/eliminarpaciente/<string:id_paciente>", methods = ["GET", "POST"])
def eliminarpaciente(id_paciente):
    if id_paciente in lista_pacientes:
        lista_pacientes.remove(id_paciente)
        return f"usuario ({id_paciente}) paciente eliminado correctamente {lista_pacientes}"


@app.route("/eliminarmedico/<string:id_medico>", methods = ["GET", "POST"])
def eliminarmedico(id_medico):
    if id_medico in lista_medicos:
        lista_medicos.remove(id_medico)
    return f"usuario ({id_medico}) medico eliminado correctamente {lista_medicos}" 


@app.route("/registrom/<string:id_medico>", methods= ["GET", "POST"])
def registromedico(id_medico):
    if id_medico:
        lista_medicos.append(id_medico)
        return f"Médico registrado exitosamente, bienvenid@ {id_medico}\n{lista_medicos}"
@app.route("/registrar2/<registrp2>", methods=["GET", "POST"])
def registrodelpaciente(registrp2):
    if request.method=="POST":
        name1 = request.form.get("nombre")
        lastname1 = request.form.get("apellido")
        age1 = request.form.get("edad")
        id31 = request.form.get("id")
        idee1= request.form.get("cedula")
        ideee1= request.form.get("tarjeta")
        phone1=request.form.get("telefono")
        email1=request.form.get("correo")
        passs1=request.form.get("contraseña")
        pro=request.form.get("profesion")
        number=request.form.get("numero")
        poss=request.form.get("posgrado")
        añadir2 = lista_medicos.append(name1)
        añadir4=lista_medicos.append(lastname1)
        añadir5=lista_medicos.append(age1)
        añadir6=lista_medicos.append(id31)
        añadir8=lista_medicos.append(phone1)
        añadir9=lista_medicos.append(email1)
        añadir10=ñista_medicos.append(passs1)
        if idee:
            añadir2=lista_medicos.append(idee1)
        elif ideee:
            añadir3=lista_medicos.append(ideee1)
        print(añadir2)
    return render_template('formularioRegistro2.html')

@app.route("/loginadmin/<login_admin>", methods= ["GET", "POST"])
def loginadmin(login_admin):
    if login_admin in lista_admin:
        return f"El usuario {login_admin} fue logueado exitosamente"
    else: 
        return f"El usuario {login_admin} no se encuentra registrado en la plataforma"

@app.route("/loginpaciente/<login_paciente>", methods= ["GET", "POST"])
def loginpaciente(login_paciente):
    if login_paciente in lista_pacientes:
        return f"El usuario {login_paciente} fue logueado exitosamente"
    else: 
        return f"El usuario {login_paciente} no se encuentra registrado en la plataforma"

@app.route("/loginmedico/<login_medico>", methods= ["GET", "POST"])
def loginmedico(login_medico):
    if login_medico in lista_medicos:
        return f"El usuario {login_medico} fue logueado exitosamente"
    else: 
        return f"El usuario {login_medico} no se encuentra registrado en la plataforma"

@app.route("/paginapaciente/<id_comentario>", methods= ["GET", "POST"])
def paginapaciente(id_comentario):
    if id_comentario in lista_comentarios:
        return lista_comentarios[id_comentario]
    else:
        return "El comentario que busca no existe"

@app.route("/paginaadmin/<id_comentario>", methods= ["GET", "POST"])
def paginaadmin(id_comentario):
    if id_comentario in lista_comentarios:
        return lista_comentarios[id_comentario]
    else:
        return "El comentario que busca no existe"

@app.route("/paginaadmin/eliminar_comentario/<eliminar_comentario>", methods= ["GET", "POST"])
def eliminar_comentarios(eliminar_comentario):
    if eliminar_comentario in lista_comentarios:
        del lista_comentarios[eliminar_comentario]
        return lista_comentarios
     

    

@app.route("/paginacitas/<string:id_cita>", methods= ["GET", "POST"])
def paginacitas(id_cita):
    if id_cita in lista_citas:
        return lista_citas[id_cita]
    else: 
        return f"la lista ({id_cita}) que está solicitando no se encuentra en nuestro sistema"

@app.route("/paginacitadesc", methods= ["GET", "POST"])
def paginacitadesc():
    return "pagina descripcion de citas"

@app.route("/dashboard", methods= ["GET"])
def dashboard():
    return "dashboard administrativo"

@app.route("/perfilmedico", methods= ["GET", "POST"])
def perfilmedico():
    return "perfil medico"

@app.route("/resultadosbusqueda", methods= ["GET", "POST"])
def resultadosbusqueda():
    return "resultados de busqueda"

if __name__ == "__main__":
    app.run(debug=True)